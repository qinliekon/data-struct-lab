void done_SqList();
void done_linklist();